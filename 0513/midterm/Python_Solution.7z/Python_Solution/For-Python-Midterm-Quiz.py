# -*- coding: utf-8 -*-
"""
Created on Sun Apr 21 21:57:30 2024
@author: richwang

part of Midterm solutions
"""
#------------------------------------------------------
'''
fname = "names-10000.txt"

with open(fname, "r") as fp:
#with open(fname, "r", encoding='utf-8') as fp:
    data = fp.read()
    names = data.split(', ')
    
print(names)
surname1 = '賴' 
surname2 = '梁'
count = [0, 0]  # or [0] * 2

for name in names:
    if name[0] == surname1:
        count[0] += 1
    if name[0] == surname2:
        count[1] += 1 
        
print(surname1, count[0])
print(surname2, count[1])
#'''
#------------------------------------------------------
'''
fname = "54007.txt"
my_info = "不分系 54007 王大同"
msg = "國立台北科技大學"

with open(fname, "w", encoding='utf-8') as fp:
    fp.write(my_info)
    
    for k in range(len(msg)):
        s = msg[k:] + msg[:k]
        #s = msg[-k:] + msg[:-k]
        print(s)
        fp.write('\n' + s)
#'''
#------------------------------------------------------
# 使用附加的方式，來將資料加入檔案。
'''
# case 1:
fname = "54007-1.txt"
with open(fname, "w", encoding='utf-8') as fp:
    fp.write("不分系")    # line 1
    fp.write("\n54007")  # line 2
    fp.write("\n王大同")  # line 3
    
# case 2: 
fname = "54007-2.txt"
# write:
with open(fname, "w", encoding='utf-8') as fp:
    fp.write("不分系")  # line 1
    
# append:    
with open(fname, "a", encoding='utf-8') as fp:
    fp.write("\n54007")  # line 2
    
# append again:    
with open(fname, "a", encoding='utf-8') as fp:
    fp.write("\n王大同")  # line 3
#'''
#------------------------------------------------------
'''
fname = "scores-A.dat"
with open(fname, "r") as fp:
    data = fp.read()
    lines = data.strip().split('\n')
    print(lines)
    
print()
    
scores = []  # 成績串列
for line in lines[1:]:    # 拆解每一列，但跳過第一列。
    items = line.split()  # 拆解每一項。
    s = [items[0]] + [int(it) for it in items[1:]]  # 重組，並轉換成整數。
    s.append(sum(s[1:]))  # 附加上後三項的總和！
    
    scores.append(s)  # 存入成績串列中
    
print(scores)
#'''
#------------------------------------------------------

    
    
